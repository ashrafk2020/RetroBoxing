public interface IDamageable
{
    void TakeDamage(Fighter fighter, float damage);
}